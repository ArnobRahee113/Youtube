<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
	
        <div class="video p-2.5"><img src="images/website.jpg"> <a href="#"><h2 class="text-4xl">Funny panda cartoons</h2></a></div>
   		<div class="video p-2.5"><img src="images/website.jpg"> <a href="#"><h2 class="text-4xl">Funny panda cartoons</h2></a></div>
   		<div class="video p-2.5"><img src="images/website.jpg"> <a href="#"><h2 class="text-4xl">Funny panda cartoons</h2></a></div>
   		<div class="video p-2.5"><img src="images/website.jpg"> <a href="#"><h2 class="text-4xl">Funny panda cartoons</h2></a></div>
   	
   		<div class="video p-2.5"><img src="images/website.jpg"> <a href="#"><h2 class="text-4xl">Funny panda cartoons</h2></a></div>
   		<div class="video p-2.5"><img src="images/website.jpg"> <a href="#"><h2 class="text-4xl">Funny panda cartoons</h2></a></div>
   		<div class="video p-2.5"><img src="images/website.jpg"> <a href="#"><h2 class="text-4xl">Funny panda cartoons</h2></a></div>
   		<div class="video p-2.5"><img src="images/website.jpg"> <a href="#"><h2 class="text-4xl">Funny panda cartoons</h2></a></div>
   	
   		
</body>
</html>