<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
	<div class="flex ">
		<button onclick="myFunction()" class="mt-5 pl-2 t"><i class="fa fa-bars" aria-hidden="true"></i></button><a href="#" class="desktop"><i class="fab fa-youtube text-4xl text-red-600 pl-5 mt-4 res"></i></a><a href="#"><p class="text-3xl mt-4 pl-2 font-medium desktop">Youtube</p></a>
		<form action="" target="blank" class="flex desktop">
			
			 <textarea  name="comment" placeholder="Search" rows=1 cols=60  class="border-2  ml-12 mt-4 desktop" ></textarea>

			 <div class="search" style="margin-top:14px;"><button  class="p-2 px-8 "><i class="fa fa-search" aria-hidden="true"></i></button></div>
			
		</form>
			
              <textarea  name="comment" placeholder="Search" rows=1 cols=30  class="border-2  ml-12 mt-4 mobile" id="search" ></textarea>
			 <div  style="margin-top:14px;" class="mobile" ><button  class="p-2 px-8 " onclick="mobileFunc()"><i class="fa fa-search" aria-hidden="true"></i></button></div>
		
   </div>
  
</body>
<script type="text/javascript" src="script.js"></script>
</html>