<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
</head>
<body>
  <nav id="t">
  	<ul >
  		<li ><a href="#">Home <i class="fa fa-home" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Trending <i class="fa fa-fire" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Library <i class="fa fa-book fa-fw" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Subscription <i class="fa fa-bell" aria-hidden="true"></i></a></li>
  		 <li><a href="#">History <i class="fa fa-clock-o" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Watch Later <i class="fa fa-clock-o" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Liked Videos<i class="fa fa-thumbs-up" aria-hidden="true"></i></a></li>
  		           <li>Subscriptions</li>
  		 <li><a href="#">Music <i class="fa fa-music" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Gaming <i class="fa fa-gamepad" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Sports <i class="fa fa-trophy" aria-hidden="true"></i></li>
  		 <li><a href="#">News <i class="fa fa-newspaper-o" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Settings <i class="fa fa-cogs" aria-hidden="true"></i></a></li>

  		 <li><a href="#">Home <i class="fa fa-home" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Trending <i class="fa fa-fire" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Library <i class="fa fa-book fa-fw" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Subscription <i class="fa fa-bell" aria-hidden="true"></i></a></li>
  		 <li><a href="#">History <i class="fa fa-clock-o" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Watch Later <i class="fa fa-clock-o" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Liked Videos<i class="fa fa-thumbs-up" aria-hidden="true"></i></a></li>
  		           <li>Subscriptions</li>
  		 <li><a href="#">Music <i class="fa fa-music" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Gaming <i class="fa fa-gamepad" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Sports <i class="fa fa-trophy" aria-hidden="true"></i></li>
  		 <li><a href="#">News <i class="fa fa-newspaper-o" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Settings <i class="fa fa-cogs" aria-hidden="true"></i></a></li>

         <li><a href="#">Home <i class="fa fa-home" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Trending <i class="fa fa-fire" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Library <i class="fa fa-book fa-fw" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Subscription <i class="fa fa-bell" aria-hidden="true"></i></a></li>
  		 <li><a href="#">History <i class="fa fa-clock-o" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Watch Later <i class="fa fa-clock-o" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Liked Videos<i class="fa fa-thumbs-up" aria-hidden="true"></i></a></li>
  		           <li>Subscriptions</li>
  		 <li><a href="#">Music <i class="fa fa-music" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Gaming <i class="fa fa-gamepad" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Sports <i class="fa fa-trophy" aria-hidden="true"></i></li>
  		 <li><a href="#">News <i class="fa fa-newspaper-o" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Settings <i class="fa fa-cogs" aria-hidden="true"></i></a></li>

<li><a href="#">Home <i class="fa fa-home" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Trending <i class="fa fa-fire" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Library <i class="fa fa-book fa-fw" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Subscription <i class="fa fa-bell" aria-hidden="true"></i></a></li>
  		 <li><a href="#">History <i class="fa fa-clock-o" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Watch Later <i class="fa fa-clock-o" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Liked Videos<i class="fa fa-thumbs-up" aria-hidden="true"></i></a></li>
  		           <li>Subscriptions</li>
  		 <li><a href="#">Music <i class="fa fa-music" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Gaming <i class="fa fa-gamepad" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Sports <i class="fa fa-trophy" aria-hidden="true"></i></li>
  		 <li><a href="#">News <i class="fa fa-newspaper-o" aria-hidden="true"></i></a></li>
  		 <li><a href="#">Settings <i class="fa fa-cogs" aria-hidden="true"></i></a></li>


  	</ul>
  </nav>
</body>
</html>